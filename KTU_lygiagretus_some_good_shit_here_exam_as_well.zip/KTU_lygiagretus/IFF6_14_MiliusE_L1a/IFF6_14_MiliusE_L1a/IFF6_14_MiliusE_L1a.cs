﻿//1. visos vienu metu
//2. atsitiktine
//3. vienos dalį
//4. atsitiktine
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;

namespace IFF6_14_MiliusE_L1a
{
    class IFF6_14_MiliusE_L1a
    {
        static void Main(string[] args)
        {
            List<Player> players = new List<Player>();
            List<Team> teams = new List<Team>();
            List<DThread> P = new List<DThread>();
            ReadData(teams);
            double a;
            a = Math.Pow(10, 105) * Math.Pow(10, -105)  * Math.Pow(10, 104) * Math.Pow(10, -104) * Math.Pow(10, 103) * Math.Pow(10, -103) * Math.Pow(10, 102) * Math.Pow(10, -102) * Math.Pow(10, 101) * Math.Pow(10, -101);
            Console.WriteLine(a);
            //for (int i = 0; i < teams.Count; i++)
            //{
            //    Console.WriteLine(teams[i].ToString());
            //    for (int j = 0; j < teams[i].Players.Count; j++)
            //    {
            //        Console.WriteLine(teams[i].Players[j].ToString());
            //    }
            //}

            //SaveReportToFile(teams);
            //Thread myNewThread = new Thread(() => MyMethod("gija_1", teams[0].Players, P));
            //Thread myNewThread1 = new Thread(() => MyMethod("gija_2", teams[1].Players, P));
            //Thread myNewThread2 = new Thread(() => MyMethod("gija_3", teams[2].Players, P));
            //Thread myNewThread3 = new Thread(() => MyMethod("gija_4", teams[3].Players, P));
            //Thread myNewThread4 = new Thread(() => MyMethod("gija_5", teams[4].Players, P));
            //myNewThread.Start();
            //myNewThread1.Start();
            //myNewThread2.Start();
            //myNewThread3.Start();
            //myNewThread4.Start();
            //myNewThread.Join();
            //myNewThread1.Join();
            //myNewThread2.Join();
            //myNewThread3.Join();
            //myNewThread4.Join();

            //for (int i = 0; i < P.Count; i++)
            //{
            //    Console.WriteLine(P[i].ToString());
            //}
            //AppendReportToFile(P);
        }

        private static void MyMethod(string name, List<Player> p, List<DThread> P)
        {
            for (int i = 0; i < p.Count; i++)
            {
                
                DThread a = new DThread(name, i+1, p[i].Name, p[i].Surname, p[i].Height, p[i].Weight);
                for (int ii = 0; ii < 10000; ii++)
                {
                    double x = Math.Sqrt(2.5);
                }
                P.Add(a);
            }
        }

        // metodas nuskaito duomenis iš failo bei sukuria 
        private static void ReadData(List<Team> teams)
        {
            int i = -1;
            using (StreamReader reader = new StreamReader(@"IFF6-14_MiliusE_L1a_dat.txt"))
            {
                string line = null;
                while (null != (line = reader.ReadLine())) // skaitymas vykdomas, kol ...
                {
                    string[] values = line.Split(' '); // nurodo iki kur skaityti duomenis vienoje eilutėje
                    if (values.Count() == 1)
                    {
                        Team a = new Team(line);
                        teams.Add(a);
                        i++;
                    }
                    else {
                            string name = values[0]; // priskiria reikšmes
                            string surname = values[1];
                            double height = double.Parse(values[2]);
                            int weight = int.Parse(values[3]);
                            Player player = new Player(name, surname, height, weight);
                            teams[i].Players.Add(player);
                    }
                    //players[playerCount++] = player;
                }
            }
        }

        //metodas 
        static void SaveReportToFile(List<Team> teams)
        {
            // lentelės šablonas
            const string topic = "|Vardas      |Pavardė      |Ūgis  |Svoris |\r\n";

            using (StreamWriter writer = new StreamWriter(@"IFF6-14_MiliusE_L1a_rez.txt")) //  sukuriamas kreipinys rasyti duomenis į failą, nurodoma kokį failą sukurti
            {
                for (int i = 0; i < teams.Count; i++) {
                    writer.WriteLine("*** {0} ***", teams[i].Nickname);
                    writer.Write(topic);
                    for (int j = 0; j < teams[i].Players.Count; j++)
                    {
                        writer.WriteLine("{0}){1, -12}{2, -13} {3}m {4, 5}kg", j+1, teams[i].Players[j].Name,
                            teams[i].Players[j].Surname, teams[i].Players[j].Height, teams[i].Players[j].Weight);
                    }
                    writer.WriteLine();
                }
                //if (players[i].Position == "Top")
                //writer.WriteLine("| {0,-8} | {1, -8} | {2,-8} | {3,-8} |", players[i].Team, players[i].Surname, players[i].Name, players[i].Champ);
                writer.WriteLine("----------------------------------------------------------------------");
            }
        }

        static void AppendReportToFile(List<DThread> P)
        {
            // lentelės šablonas
            const string topic = "|Gijos nr. |Indeksas  |Vardas      |Pavardė      |Ūgis, m  |Svoris, kg |\r\n";
            using (StreamWriter writer = File.AppendText(@"IFF6-14_MiliusE_L1a_rez.txt"))
            {
                writer.Write(topic);
                for (int i = 0; i < P.Count; i++)
                {
                    writer.WriteLine(" {0,-14} {1, -6} {2, -12} {3, -14} {4, -12} {5}", P[i].threadName, P[i].listName,
                              P[i].playerName, P[i].playerSurname, P[i].playerHeight, P[i].playerWeight);
                }
                writer.WriteLine("----------------------------------------------------------------------");
            }
        }
    }

    class Player
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public double Height { get; set; }
        public int Weight { get; set; }


        public Player(string name, string surname, double height, int weight)
        {
            Name = name;
            Surname = surname;
            Height = height;
            Weight = weight;
        }

        public override string ToString()
        {
            return String.Format("{0} {1} {2} {3}", Name, Surname, Height, Weight);
        }
    }
    class Team
    {
        public List<Player> Players;
        public string Nickname { get; set; }

        public Team(string nickname)
        {
            Nickname = nickname;
            Players = new List<Player>();
        }
        public override string ToString()
        {
            return String.Format("{0}", Nickname);
        }
    }
    class DThread
    {
        public string threadName { get; set; }
        public int listName { get; set; }
        public string playerName { get; set; }
        public string playerSurname { get; set; }
        public double playerHeight { get; set; }
        public int playerWeight { get; set; }

        public DThread(string threadname, int listname, string name, string surname, double height, int weight)
        {
            threadName = threadname;
            listName = listname;
            playerName = name;
            playerSurname = surname;
            playerHeight = height;
            playerWeight = weight;
        }

        public override string ToString()
        {
            return String.Format("{0} {1} {2} {3} {4} {5}", threadName, listName, playerName, playerSurname
                , playerHeight, playerWeight);
        }
    }
}
