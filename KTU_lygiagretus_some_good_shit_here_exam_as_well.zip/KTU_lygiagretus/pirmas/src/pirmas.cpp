//============================================================================
// Name        : pirmas.cpp
// Author      : Paulius
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================


#include <iostream>
#include <omp.h>
#include <cstring>
#include <array>
#include <string>
#include <fstream>
#include <sstream>
#include <thread>
#include <iomanip>
#include "../picosha2.h"


using namespace std;

class Stream {
public:
	int id;
	string name;
	float viewCount;
	string hash;
};

static void PrintDataToFile(Stream data[], int amount, bool append);
void AddStreamToResultArray(Stream Stream);
bool IsHashValid(string hash);
static string GetStreamHash(Stream Stream);
static void PrintData(Stream data[], int amount);
static void ReadData(string fileName, Stream streams[]);
const int ARRAY_SIZE = 40;

Stream StreamResults[ARRAY_SIZE];
int resultCount = 0;

class MyMonitor {
private:
	Stream workStream[ARRAY_SIZE / 2];

	int scannedDataAmount;

	bool isFinished;
	bool isDataArrayEmpty;
public:
	MyMonitor();
	int workCount;
	void put(Stream new_Stream);
	Stream get();

	void putResult(Stream Stream);

	void set_isFinished();
	bool get_isFinished();

	void set_isDataArrayEmpty();
};

MyMonitor::MyMonitor() {

	workCount = 0;
	scannedDataAmount = 0;
	resultCount = 0;
	isFinished = false;
	isDataArrayEmpty = false;
}

void MyMonitor::set_isFinished() {
	isFinished = true;
}

bool MyMonitor::get_isFinished() {
	return isFinished;
}

void MyMonitor::set_isDataArrayEmpty() {
	isDataArrayEmpty = true;
}


void MyMonitor::put(Stream new_Stream) {

	#pragma omp critical(critical1)
	{
		workStream[workCount++] = new_Stream;
	}
}

Stream MyMonitor::get() {

	Stream stream;
	stream.name = "null";

	while (workCount <= 0 && !get_isFinished())
	{

	}

	#pragma omp critical(critical1)
	{
		if (workCount > 0)
		{
			stream = workStream[workCount - 1];
			workCount--;
			scannedDataAmount++;

			if (scannedDataAmount >= ARRAY_SIZE)
			{
				set_isFinished();
			}
		}
	}

	return stream;
}

void MyMonitor::putResult(Stream stream) {

	#pragma omp critical(critical1)
	{
		AddStreamToResultArray(stream);
	}

}

int main()
{

	string DataFileName = "data2.txt";
	ifstream file(DataFileName);
	string line;

	Stream streamsData[ARRAY_SIZE];

	ReadData(DataFileName, streamsData);
	PrintData(streamsData, ARRAY_SIZE);
	PrintDataToFile(streamsData, ARRAY_SIZE, false);

	MyMonitor monitor;
	int i = 0;

	#pragma omp parallel firstprivate(i) num_threads(4)
	{
		int tid = omp_get_thread_num();

		if (tid == 0)
		{
			while (i < ARRAY_SIZE)
			{
				if (monitor.workCount < ARRAY_SIZE / 2)
				{
					monitor.put(streamsData[i]);
					i++;
				}
			}
			monitor.set_isDataArrayEmpty();
		}
		else
		{
			while (!monitor.get_isFinished())
			{
				Stream received_Stream = monitor.get();
				received_Stream.hash = GetStreamHash(received_Stream);

				if (IsHashValid(received_Stream.hash) && received_Stream.name != "null")
					monitor.putResult(received_Stream);
			}
		}
	}

	cout << "Printing results" << endl;
	//PrintData(StreamResults, resultCount);
	PrintDataToFile(StreamResults, resultCount, true);

	return 0;
}

void AddStreamToResultArray(Stream stream)
{
	Stream tempStream;
	bool reachedLarger = false;

	for (int i = 0; i < resultCount + 1; i++)
	{
		if (reachedLarger)
		{
			Stream temp2Stream = StreamResults[i];
			StreamResults[i] = tempStream;
			tempStream = temp2Stream;

		}
		else
		{
			if (StreamResults[i].hash.compare(stream.hash) < 0)
			{
				tempStream = StreamResults[i];
				StreamResults[i] = stream;
				reachedLarger = true;
			}
		}
	}

	if (resultCount <= 0)
		StreamResults[resultCount] = stream;

	resultCount++;
}

bool IsHashValid(string hash)
{
	int startSymbol = hash[0];
	if (startSymbol >= 48 && startSymbol <= 100) // ASCII 0 - 48, 9 - 57
	//if (startSymbol >= 48 && startSymbol <= 53) // ASCII 0 - 48, 9 - 57
	//if (startSymbol < 48) // ASCII 0 - 48, 9 - 57
		return true;

	return false;
}

static string GetStreamHash(Stream stream)
{
	string input = stream.name + to_string(stream.id) + to_string(stream.viewCount);
	string outputHash = "";

	for(size_t i = 0; i < input.length(); i++){
			outputHash += to_string(((int)input[i]-48)%10);
	}

	string hash256 = picosha2::hash256_hex_string(input);
	cout << "Hash: " << hash256 << "\n" << endl;

	return hash256;
}

static void ReadData(string fileName, Stream streams[]) {
	ifstream file(fileName);
	string line;

	if (file.is_open()) {
		int currentMember = 0;

		while (getline(file, line))
		{
			string arr[4];
			stringstream ssin(line);
			string token;

			getline(ssin, token, ',');
			int id = stoi(token);

			getline(ssin, token, ',');
			string name = token;

			getline(ssin, token, ',');
			float viewCount = stof(token);

			streams[currentMember].id = id;
			streams[currentMember].name = name;
			streams[currentMember].viewCount = viewCount;
			currentMember++;
		}

	}
	file.close();
}

static void PrintDataToFile(Stream data[], int amount, bool append)
{
	ofstream ofstream;
	if (append)
	{
		ofstream.open("results.txt", std::ofstream::out | std::ofstream::app);
		ofstream << "================================================================" << endl;
		ofstream << setw(7) << "ID" << "  " << setw(30) << left << "Name" << "  " << setw(16) << "View count" << setw(-70) << "Hash" << endl;

	}
	else
	{
		ofstream.open("results.txt");
		ofstream << setw(7) << "ID" << "  " << setw(30) << left << "Name" << "  " << setw(16) << "View count" << endl;
	}


	for (int i = 0; i < amount; i++)
	{
		ofstream << setw(2) << i <<". " << setw(3) << data[i].id << "  " << setw(30) << left << data[i].name << "  " << setw(16) << data[i].viewCount<< setw(70) << data[i].hash << endl;
	}
	ofstream.close();
}

static void PrintData(Stream data[], int amount)
{

	for (int i = 0; i < amount; i++)
	{
		cout << data[i].id<< "  " << data[i].name << "  " << data[i].viewCount << endl << data[i].hash << endl << "----------------------------------------------------------------" << endl;
	}
}
