package main

import (
	"custom/point"
	"custom/vector"
	"math"
	"math/rand"
	"os"
	"runtime"
	"runtime/debug"
	"strconv"
	"time"
)

const delta = 0.0001
const numberOfTimesToRepeat = 4

type SpecificPointDirection struct {
	gradient vector.Vector
	id       int
}

func main() {
	writer, _ := os.Create("result.csv")
	writer.WriteString(" 	Point count ,	Thread count,	Time\n")
	rand.Seed(time.Now().UTC().UnixNano())

	debug.SetGCPercent(-1)

	//Points
	for i := 2; i <= 20; i += 2 {
		//Threads
		for thread := 1; thread <= 20; thread++ {

			//Average time

			var avgTime = 0.0

			writer.WriteString("points " + strconv.Itoa(i *3) + "  thread " + strconv.Itoa(thread)+"\n")

			staticPoints := point.RandomArray(i)
			dynamicPoints := point.RandomArray(i*2)

			for j := 0; j < numberOfTimesToRepeat; j++ {

				runtime.GC()

				startTime := time.Now()
				calculationInitialization(staticPoints, dynamicPoints , thread)
				endTime := time.Now()
				elapsedTime := endTime.Sub(startTime).Seconds() * 1000
				avgTime += elapsedTime

				writer.WriteString(strconv.FormatFloat(elapsedTime, 'f', 0, 64) + " ")

			}

			avgTime /= numberOfTimesToRepeat

			writer.WriteString("\n                           TOTAL " + strconv.FormatFloat(avgTime, 'f', 0, 64) + "\n")
			writer.WriteString(" ----------------------------------------------------------------------------\n")
		}
		writer.WriteString("***************************************************************************\n")

		writer.WriteString("\n")
	}
}

func calculationInitialization(staticPoints []point.Point, dynamicPoints []point.Point, threadCount int) {

	dynamicPointsAmount := len(dynamicPoints)
	allPoints := append(dynamicPoints, staticPoints...)

	gradientChannel := make(chan SpecificPointDirection, threadCount)

	var temporaryDynamicPoints []int

	for i := 0; i < dynamicPointsAmount; i++ {
		temporaryDynamicPoints = append(temporaryDynamicPoints, i)
	}

	var threadLoad [][]int

	loadSize := dynamicPointsAmount / threadCount

	if len(temporaryDynamicPoints) < threadCount {
		for i := 0; i < len(temporaryDynamicPoints); i++ {
			threadLoad = append(threadLoad, []int{temporaryDynamicPoints[i]})
		}
	} else {

		for i := 0; i < len(dynamicPoints); i += loadSize {
			end := i + loadSize
			if end > len(temporaryDynamicPoints) {
				end = len(temporaryDynamicPoints)
			}
			threadLoad = append(threadLoad, temporaryDynamicPoints[i:end])
		}
	}

	//fmt.Printf("ThreadCount %d  Dynamic points %d Static points %d Load size %d \n",threadCount,dynamicPointsAmount,staticPointsAmount, loadSize)
	//fmt.Println(threadLoad)

	for {
		previousValue := point.ArrayDistanceDifferenceSum(allPoints)
		
		for i := 0; i < len(threadLoad); i++ {
			go calculationGoroutine(allPoints, threadLoad[i], gradientChannel)
		}

		var gradients = make([]SpecificPointDirection, dynamicPointsAmount)

		for i := 0; i < dynamicPointsAmount; i++ {
			gradients[i] = <-gradientChannel
		}

		for i := 0; i < dynamicPointsAmount; i++ {
			gradient := gradients[i]
			allPoints[ gradient.id ].X -= gradient.gradient.X
			allPoints[ gradient.id ].Y -= gradient.gradient.Y

		}

		if previousValue < point.ArrayDistanceDifferenceSum(allPoints) {
			break
		}
	}
}

func calculationGoroutine(points []point.Point, threadLoad []int, resultChannel chan SpecificPointDirection) {
	for i := 0; i < len(threadLoad); i++ {

		grad1 := distanceGradient(points, threadLoad[i])

		if(grad1.X != 0 && grad1.Y !=0) {
			grad1 = grad1.Normalized()
		}

		grad2 := functionGradient(points[threadLoad[i]])

		if(grad2.X != 0 && grad2.Y !=0) {
			grad2 = grad2.Normalized()
		}

		gradient := vector.New(grad1.X+grad2.X, grad1.Y+grad2.Y)
		gradient = gradient.Normalized()

		resultChannel <- SpecificPointDirection{gradient, threadLoad[i]}
	}
}

func distanceGradient(points []point.Point, id int) vector.Vector {
	xPoints := point.CopyArray(points)
	xPoints[id].X += delta

	yPoints := point.CopyArray(points)
	yPoints[id].Y += delta

	gradientX := (point.ArrayDistanceDifferenceSum(xPoints) - point.ArrayDistanceDifferenceSum(points)) / delta
	gradientY := (point.ArrayDistanceDifferenceSum(yPoints) - point.ArrayDistanceDifferenceSum(points)) / delta

	return vector.New(gradientX, gradientY)
}

func functionGradient(currentPoint point.Point) vector.Vector {
	gradientX := (function(point.New(currentPoint.X+delta, currentPoint.Y)) - function(currentPoint)) / delta
	gradientY := (function(point.New(currentPoint.X, currentPoint.Y+delta)) - function(currentPoint)) / delta
	return vector.New(gradientX, gradientY)
}

func function(p point.Point) float64 {
	sas :=  p.X*math.Pow(math.E, -((p.X*p.X+p.Y*p.Y)/10)) + 1.5

	return sas
}
