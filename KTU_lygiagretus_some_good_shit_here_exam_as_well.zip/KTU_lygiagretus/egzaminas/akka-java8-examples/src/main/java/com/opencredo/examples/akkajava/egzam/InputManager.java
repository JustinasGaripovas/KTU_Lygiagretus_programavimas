package com.opencredo.examples.akkajava.egzam;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

import static akka.japi.pf.ReceiveBuilder.match;

public class InputManager extends AbstractActor {

    public static final int BATCH_SIZE = 10;
    private final ActorRef router;
    Meteor[] innerMemory = new Meteor[BATCH_SIZE];

    int index = 0;

    public static Props props(final ActorRef router) {
        return Props.create(InputManager.class, () -> new InputManager(router));
    }

    public InputManager(final ActorRef router) {
        this.router = router;

        receive(
                match(Meteor.class, meteor -> {
                    innerMemory[index++] = meteor;
                    if (index == BATCH_SIZE) {
                        tellInnerMemory();
                    }
                })
                .match(Integer.class, error -> {
                    tellInnerMemory();
                })
                .matchAny(this::unhandled)
                .build()
        );
    }

    /*
        Sends all stored meteors to router
     */
    private void tellInnerMemory() {
        if (this.router == null && innerMemory.length <= 0)
            return;

        for (Meteor m : innerMemory) {
            this.router.tell(m, null);
        }

        index = 0;
    }
}
