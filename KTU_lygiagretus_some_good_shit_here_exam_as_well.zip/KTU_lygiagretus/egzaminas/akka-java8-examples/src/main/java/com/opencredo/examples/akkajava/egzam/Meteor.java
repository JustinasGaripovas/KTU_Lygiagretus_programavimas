package com.opencredo.examples.akkajava.egzam;

public class Meteor {

    private String name;
    private int hazard_level;
    private double relative_velocity;
    private double diameter;
    private double damage_impact = 0;

    public Meteor(String name, int hazard_level, double relative_velocity, double diameter) {

        this.name = name;
        this.hazard_level = hazard_level;
        this.relative_velocity = relative_velocity;
        this.diameter = diameter;
    }

    @Override
    public String toString() {
        return String.format("%26s %13d %20f %15f %15f \n", name, hazard_level, relative_velocity, diameter, damage_impact);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getRelative_velocity() {
        return relative_velocity;
    }

    public void setRelative_velocity(double relative_velocity) {
        this.relative_velocity = relative_velocity;
    }

    public double getDiameter() {
        return diameter;
    }

    public void setDiameter(double diameter) {
        this.diameter = diameter;
    }

    public int getHazard_level() {
        return hazard_level;
    }

    public void setHazard_level(int hazard_level) {
        this.hazard_level = hazard_level;
    }

    public double getDamage_impact() {
        return damage_impact;
    }

    public void setDamage_impact(double damage_impact) {
        this.damage_impact = damage_impact;
    }
}
