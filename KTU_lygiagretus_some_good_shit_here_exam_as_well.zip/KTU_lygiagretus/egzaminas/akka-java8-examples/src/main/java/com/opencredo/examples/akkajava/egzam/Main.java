package com.opencredo.examples.akkajava.egzam;

import akka.actor.ActorRef;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.routing.RoundRobinPool;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Main {
    public static final int FILE_INDEX = 0;
    public static String[] FILE_PATHS = new String[]{
        "/home/justin/Documents/KTU_lygiagretus/egzaminas/akka-java8-examples/src/main/java/com/opencredo/examples/akkajava/egzam/data/IFF7-9_GaripovasJ_L1a_dat_1.json",
        "/home/justin/Documents/KTU_lygiagretus/egzaminas/akka-java8-examples/src/main/java/com/opencredo/examples/akkajava/egzam/data/IFF7-9_GaripovasJ_L1a_dat_2.json",
        "/home/justin/Documents/KTU_lygiagretus/egzaminas/akka-java8-examples/src/main/java/com/opencredo/examples/akkajava/egzam/data/IFF7-9_GaripovasJ_L1a_dat_3.json"
    };

    static List<Meteor> meteorList = new ArrayList<Meteor>();

    public static void main(String[] args) throws Exception {

        final Config config = ConfigFactory.load();

        readData();

        final ActorSystem system = ActorSystem.create("MainSystem", config);

        try {
            ActorRef outputManager = system.actorOf(OutputManager.props(meteorList.size()), "OutputManager");
            ActorRef router = system.actorOf(Props.create(Worker.class, () -> new Worker(outputManager)).withRouter(new RoundRobinPool(5)), "RoundRobinPool");
            ActorRef inputManager = system.actorOf(InputManager.props(router), "InputManager");

            for (Meteor m : meteorList) {
                inputManager.tell(m,null);
            }

            inputManager.tell(0, null);

        } catch (Exception e) {
            system.terminate();
            throw e;
        }
    }

    public static void readData()
    {
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader(FILE_PATHS[FILE_INDEX]))
        {
            Object obj = jsonParser.parse(reader);
            JSONArray employeeList = (JSONArray) obj;
            employeeList.forEach( emp -> parseMeteorObject( (JSONObject) emp ) );
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    private static void parseMeteorObject(JSONObject employee)
    {
        JSONObject employeeObject = (JSONObject) employee.get("meteor");
        String name = (String) employeeObject.get("name");
        Long hazard_level = (Long) employeeObject.get("hazard_level");
        double relative_velocity = (double)employeeObject.get("relative_velocity");
        double diameter = (double)employeeObject.get("diameter");
        meteorList.add(new Meteor(name, hazard_level.intValue(), relative_velocity, diameter));
    }
}