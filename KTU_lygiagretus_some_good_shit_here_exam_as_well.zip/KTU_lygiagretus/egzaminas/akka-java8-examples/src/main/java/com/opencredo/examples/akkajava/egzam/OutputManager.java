package com.opencredo.examples.akkajava.egzam;

import akka.actor.AbstractActor;
import akka.actor.AbstractLoggingActor;
import akka.actor.ActorRef;
import akka.actor.Props;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import static akka.japi.pf.ReceiveBuilder.match;

public class OutputManager extends AbstractActor {

    public static final String FILE_PATH = "/home/justin/Documents/KTU_lygiagretus/egzaminas/akka-java8-examples/src/main/java/com/opencredo/examples/akkajava/egzam/result.txt";
    private static boolean printed = false;

    BinaryTree meteorBinaryTree = new BinaryTree();

    int destinationDataCount = 0;
    int currentDataCount = 0;

    public static Props props(int dataCount) {
        return Props.create(OutputManager.class, () -> new OutputManager(dataCount));
    }

    public OutputManager(int dataCount)
    {
        destinationDataCount = dataCount;

        receive(
                match(Meteor.class, meteor -> {
                    currentDataCount++;

                    meteorBinaryTree.insert(meteor);

                    processOutput();
                })
                .match(Integer.class, error -> {
                    if (error == 0)
                    {
                        currentDataCount++;
                        processOutput();
                    }
                })
                .matchAny(this::unhandled)
                .build()
        );
    }

    private void processOutput() throws IOException {
        if (currentDataCount >= destinationDataCount) {
            manageFileOutput(meteorBinaryTree.getSortedList());
        }
    }

    public static void manageFileOutput(ArrayList<Meteor> meteors) throws IOException
    {
        if (printed)
            return;

        File tempFile = new File(FILE_PATH);
        boolean exists = tempFile.exists();

        if (exists)
        {
            deleteOutputFile();
        }

        FileWriter fw = new FileWriter(FILE_PATH);

        BufferedWriter writer = new BufferedWriter(fw);

        writer.write(String.format("%26s %13s %20s %15s %15s \n", "Pavadinimas", "Žalos lygis", "Realiatyvus greitis", "Diameteras", "Žalos galia"));

        for (Meteor m : meteors ) {
            writer.write(m.toString());
        }

        writer.close();

        printed = true;

        System.out.println("END OF PROGRAM");
    }

    public static void deleteOutputFile()
    {
        File file = new File(FILE_PATH);
        file.delete();
    }
}
