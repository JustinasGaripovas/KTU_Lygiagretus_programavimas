package com.opencredo.examples.akkajava.egzam;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

import static akka.japi.pf.ReceiveBuilder.match;

public class Worker extends AbstractActor {

    public static final int RECALCULATION_ITERATIONS = 5000;
    private final ActorRef OutputManager;

    public static Props props(final ActorRef OutputManager) {
        return Props.create(Worker.class, () -> new Worker(OutputManager));
    }

    public Worker(final ActorRef OutputManager) {
        this.OutputManager = OutputManager;

        receive(
                match(Meteor.class, meteor -> {
                    Meteor resultMeteor = recalculateMeteorHazardLevel(meteor);

                    if (doesMeteorFitRequirements(resultMeteor)) {
                        this.OutputManager.tell(resultMeteor, null);
                    } else {
                        this.OutputManager.tell(0, null);
                    }
                })
                .matchAny(this::unhandled)
                .build()
        );
    }

    private boolean doesMeteorFitRequirements(Meteor meteor) {
        return meteor.getHazard_level() > 3;
    }

    /*
        Calculates meteor hazard
     */
    private Meteor recalculateMeteorHazardLevel(Meteor meteor) {
        double diameter = meteor.getDiameter();

        for (int i = 0; i < RECALCULATION_ITERATIONS; i++) {

            if (diameter <= 0) {
                diameter = 0;
                break;
            }

            diameter -= meteor.getRelative_velocity() * 0.001;
        }

        if (diameter > 1000) {
            meteor.setHazard_level(5);
        } else if (diameter > 500) {
            meteor.setHazard_level(4);
        } else if (diameter > 250) {
            meteor.setHazard_level(3);
        } else if (diameter > 100) {
            meteor.setHazard_level(2);
        } else {
            meteor.setHazard_level(1);
        }

        meteor.setDamage_impact((meteor.getHazard_level()*50 * meteor.getRelative_velocity())/50);

        return meteor;
    }

}
