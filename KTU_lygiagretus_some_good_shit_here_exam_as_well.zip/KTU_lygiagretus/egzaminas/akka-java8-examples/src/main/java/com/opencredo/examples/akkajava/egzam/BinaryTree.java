package com.opencredo.examples.akkajava.egzam;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class BinaryTree {

    ArrayList<Meteor> sortedList = new ArrayList<Meteor>();

    public ArrayList<Meteor> getSortedList() {

        sortedList = new ArrayList<Meteor>();

        inorderRec(root);

        return sortedList;
    }

    class Node
    {
        Meteor key;
        Node left, right;

        public Node(Meteor item)
        {
            key = item;
            left = right = null;
        }
    }

    Node root;

    BinaryTree()
    {
        root = null;
    }

    void insert(Meteor key)
    {
        root = insertRec(root, key);
    }

    Node insertRec(Node root, Meteor key)
    {
        if (root == null)
        {
            root = new Node(key);
            return root;
        }

        /* Otherwise, recur
        down the tree */
        if (key.getHazard_level() < root.key.getHazard_level())
            root.left = insertRec(root.left, key);
        else if (key.getHazard_level() > root.key.getHazard_level())
            root.right = insertRec(root.right, key);
        else if (key.getHazard_level() == root.key.getHazard_level())
            root.left = insertRec(root.left, key);

        /* return the root */
        return root;
    }

    // A function to do
    // inorder traversal of BST
    void inorderRec(Node root)
    {
        if (root != null)
        {
            inorderRec(root.left);

            sortedList.add(root.key);

            inorderRec(root.right);
        }
    }
}
