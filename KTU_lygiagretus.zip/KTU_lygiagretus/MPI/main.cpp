// Author: Wes Kendall
// Copyright 2011 www.mpitutorial.com
// This code is provided freely with the tutorials on mpitutorial.com. Feel
// free to modify it for your own use. Any distribution of the code must
// either provide a link to www.mpitutorial.com or keep this header intact.
//
// Example using MPI_Send and MPI_Recv to pass a message around in a ring.
//
#include <mpi.h>
#include <stdlib.h>
#include <iostream>

int DATA_SIZE = 10;
using namespace MPI;



void calculate_full_sum() {
    int worker_count = COMM_WORLD.Get_size() - 1;
    const auto DATA_SIZE = 10000;
    int numbers[DATA_SIZE];
    auto chunk_size = DATA_SIZE / worker_count;
    for (auto i = 0; i < worker_count; i++) {
        int end_index = (i == worker_count - 1 ? DATA_SIZE - 1 : (i + 1) * chunk_size - 1);
        int start_index = i * chunk_size;
        int current_chunk_size = end_index - start_index + 1;
        COMM_WORLD.Send(&current_chunk_size, 1, INT, i + 1, 1);
        COMM_WORLD.Send(numbers + start_index, current_chunk_size, INT, i + 1, 2);
    }

    void calculate_partial_sum() {
        int items_to_process;
        COMM_WORLD.Recv(&items_to_process, 1, INT, 0, 1);
        int items[items_to_process];
        COMM_WORLD.Recv(items, items_to_process, INT, 0, 2);
        auto total_sum = accumulate(&items[0], &items[items_to_process], 0, [](intx, inty) { returnx + y; });
        COMM_WORLD.Send(&total_sum, 1, INT, 0, 1);
    }

    int main() {
        Init();
        auto rank = COMM_WORLD.Get_rank();
        if (rank == 0) { calculate_full_sum(); } else { calculate_partial_sum(); }
        Finalize();
        return 0;
    }