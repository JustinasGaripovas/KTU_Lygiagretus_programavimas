//
// Created by justin on 2019-10-22.
//

#include "Meteor.h"
#include <iostream>

void Meteor::SetMeteorValues(std::string name, double diameter, double velocity, int hazard_level) {

    this->name = name;
    this->diameter = diameter;
    this->velocity = velocity;
    this->hazard_level = hazard_level;

}

std::string Meteor::ToString() {
    return name + " " + std::to_string(diameter) + " " + std::to_string(velocity) + " " + std::to_string(hazard_level);
}

Meteor::Meteor() {

}

std::string Meteor::GetName() {
    return name;
}

double Meteor::GetDiameter() {
    return diameter;
}

double Meteor::GetVelocity() {
    return velocity;
}

void Meteor::CalculateHazardLevel() {

    double tempDiameter = diameter;

    for (int i = 0; i < 5000; ++i) {

        if (tempDiameter <= 0){
            tempDiameter = 0;
            break;
        }

        std::cout << tempDiameter << std::endl;

        tempDiameter -= velocity * 0.001;
    }

    if (tempDiameter > 1000)
        hazard_level = 5;
    else if (tempDiameter > 500)
        hazard_level = 4;
    else if (tempDiameter > 250)
        hazard_level = 3;
    else if (tempDiameter > 100)
        hazard_level = 2;
    else if (tempDiameter > 50)
        hazard_level = 1;
    else
        hazard_level = 0;

}

bool Meteor::IsHazardous() {
    CalculateHazardLevel();
    return hazard_level > 3;
}

int Meteor::GetHazardLevel() {
    return hazard_level;
}

