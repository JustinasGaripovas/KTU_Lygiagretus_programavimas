#include <iostream>
#include "json.hpp"
#include <fstream>
#include "Meteor.h"
#include <string>
#include <thread>
#include <iomanip>
#include <condition_variable>

using json = nlohmann::json;
using namespace std;

const std::basic_string<char> INPUT_FILE_PATHS[3] = {
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/data1.json",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/data2.json",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/data3.json"
};

const std::basic_string<char> OUTPUT_FILE_PATHS[3] = {
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/result1.txt",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/result2.txt",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/result3.txt"
};

void InputFromFile(std::basic_string<char> filename);
void InputToMonitor();
void RemoveFromMonitor();

Meteor meteors[25];
int readMeteorCount = 0;

Meteor resultMeteors[25];
int resultMeteorCount = 0;

std::mutex customMutex;

std::condition_variable emptyMonitorCV;
std::condition_variable fillMonitorCV;

int main() {
    /*
     * OutputFileToConsole((string) INPUT_FILE_PATHS[0]);
     */

    InputFromFile((string) INPUT_FILE_PATHS[0]);


    thread t(InputToMonitor);
    thread t1(RemoveFromMonitor);
    thread t2(RemoveFromMonitor);

    t.join();
    t1.join();
    t2.join();

    for (int i = 0; i < (*(&meteors + 1) - meteors); ++i) {
        cout << meteors[i].ToString() << endl;
    }

}

Meteor inputArray[2];
int inputCount = 0;
int functionInputIndex = 0;
int functionRemoveIndex = 0;

void InputToMonitor()
{
    std::unique_lock<std::mutex> uniqueLock(customMutex);

    functionInputIndex++;

    fillMonitorCV.wait(uniqueLock, [&] {
        return inputCount < 2 || functionInputIndex > 2;
    });

    if (functionInputIndex > 2)
        return;

    inputArray[inputCount++] = meteors[readMeteorCount++];

    uniqueLock.unlock();
    emptyMonitorCV.notify_one();
}

void RemoveFromMonitor()
{
    std::unique_lock<std::mutex> uniqueLock(customMutex);

    functionRemoveIndex++;

    emptyMonitorCV.wait(uniqueLock, [&] {
        return inputCount <= 0 || functionRemoveIndex > 1;
    });

    if (functionRemoveIndex > 1)
        return;

    resultMeteors[resultMeteorCount++] = inputArray[inputCount];

}


void InputFromFile(string filename) {

    std::ifstream file(filename);

    json data;
    file >> data;

    int index = 0;
    for (json::iterator it = data.begin(); it != data.end(); it++) {
        std::string name = it.value().value("name", "");
        int hazard_level = it.value().value("hazard_level", 0);
        double relative_velocity = it.value().value("relative_velocity", 0.0);
        double diameter = it.value().value("diameter", 0.0);

        meteors[index].SetMeteorValues(name, diameter, relative_velocity, hazard_level);

        index++;
    }
}