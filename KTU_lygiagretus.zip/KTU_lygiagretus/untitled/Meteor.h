//
// Created by justin on 2019-10-24.
//

#ifndef UNTITLED_METEOR_H
#define UNTITLED_METEOR_H

#include <string>

class Meteor {

public:
    Meteor();
    Meteor(std::string name, double diameter, double velocity, int hazard_level);
    void SetMeteorValues(std::string name, double diameter, double velocity, int hazard_level);
    std::string ToString();
    void Copy(Meteor meteor);
    bool GetHazardLevelLow();
    std::string GetName();
    double GetDiameter();
    double GetVelocity();

private:
    std::string name;
    double diameter;
    double velocity;
    int hazard_level;

};



#endif //UNTITLED_METEOR_H
