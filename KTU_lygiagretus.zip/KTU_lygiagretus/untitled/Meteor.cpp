//
// Created by justin on 2019-10-24.
//

#include "Meteor.h"


Meteor::Meteor(std::string name, double diameter, double velocity, int hazard_level) {
    this->name = name;
    this->diameter = diameter;
    this->velocity = velocity;
    this->hazard_level = hazard_level;

}

void Meteor::SetMeteorValues(std::string name, double diameter, double velocity, int hazard_level) {

    this->name = name;
    this->diameter = diameter;
    this->velocity = velocity;
    this->hazard_level = hazard_level;

}

std::string Meteor::ToString() {
    return name + " " + std::to_string(diameter) + " " + std::to_string(velocity) + " " + std::to_string(hazard_level);
}

void Meteor::Copy(Meteor meteor) {
    this->name = meteor.name;
    this->diameter = meteor.diameter;
    this->velocity = meteor.velocity;
    this->hazard_level = meteor.hazard_level;
}

bool Meteor::GetHazardLevelLow() {
    return this->hazard_level <= 20;
}

Meteor::Meteor() {

}

std::string Meteor::GetName() {
    return name;
}

double Meteor::GetDiameter() {
    return diameter;
}

double Meteor::GetVelocity() {
    return velocity;
}
