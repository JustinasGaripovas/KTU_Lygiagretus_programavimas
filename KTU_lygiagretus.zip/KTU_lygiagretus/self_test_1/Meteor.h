//
// Created by justin on 2019-10-22.
//

#ifndef SELF_TEST_1_METEOR_H
#define SELF_TEST_1_METEOR_H

#include <string>

class Meteor {

public:
    Meteor();
    void SetMeteorValues(std::string name, double diameter, double velocity, int hazard_level);
    std::string ToString();

    bool IsHazardous();
    void CalculateHazardLevel();

    std::string GetName();
    double GetDiameter();
    int GetHazardLevel();
    double GetVelocity();

private:
    std::string name;
    double diameter;
    double velocity;
    int hazard_level;

};


#endif //SELF_TEST_1_METEOR_H
