//
// Created by justin on 2019-10-22.
//

#ifndef SELF_TEST_1_MONITOR_H
#define SELF_TEST_1_MONITOR_H

#include <mutex>
#include <condition_variable>
#include "Meteor.h"

const int ARRAY_SIZE = 28;

class Monitor {

public:
    Monitor();
    void put(Meteor new_meteor);
    void remove();
    int putCount = 0;
    int removedCount = 0;

    Meteor meteorsResults[ARRAY_SIZE];
    int meteorResultCount = 0;

    bool getFillDone();
    void setFillDone(bool fill);
    bool getRemoveDone();
    void setRemoveDone(bool remove);

    bool getAllInputsDone();
    bool getAllRemovesDone();

private:
    std::mutex mutex;
    std::condition_variable emptyMonitorCV;
    std::condition_variable fillMonitorCV;

    bool fillDone = false;
    bool removeDone= true;

    Meteor meteors[ARRAY_SIZE/2];
    int meteorsCount = 0;
};


#endif //SELF_TEST_1_MONITOR_H
