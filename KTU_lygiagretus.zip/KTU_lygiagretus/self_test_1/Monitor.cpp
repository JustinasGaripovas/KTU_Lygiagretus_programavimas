//
// Created by justin on 2019-10-22.
//

#include "Monitor.h"
#include <mutex>

void Monitor::put(Meteor meteor) {

    std::unique_lock<std::mutex> uniqueLock(mutex);

    fillMonitorCV.wait(uniqueLock, [&] {
        return getRemoveDone() || getAllInputsDone();
    });


    if (getAllInputsDone()) {
        uniqueLock.unlock();
        setFillDone(true);
        emptyMonitorCV.notify_one();
        return;
    }

    meteors[meteorsCount] = meteor;

    putCount++;
    meteorsCount++;

    uniqueLock.unlock();

    if (meteorsCount == ARRAY_SIZE / 2) {
        setFillDone(true);
        setRemoveDone(false);
        emptyMonitorCV.notify_one();
    }
}

void Monitor::remove() {

    std::unique_lock<std::mutex> uniqueLock(mutex);

    emptyMonitorCV.wait(uniqueLock, [&] {
        return getFillDone() || getAllRemovesDone();
    });

    if (getAllRemovesDone()) {
        uniqueLock.unlock();
        setRemoveDone(true);
        fillMonitorCV.notify_one();
        return;
    }

    if (meteors[meteorsCount - 1].IsHazardous()) {

        meteorsResults[meteorResultCount++] = meteors[meteorsCount - 1];

        int i, j;
        for (i = 0; i < meteorResultCount - 1; i++) {
            for (j = 0; j < meteorResultCount - i - 1; j++) {
                if (meteorsResults[j].GetHazardLevel() < meteorsResults[j + 1].GetHazardLevel()) {
                    Meteor m = meteorsResults[j];
                    meteorsResults[j] = meteorsResults[j + 1];
                    meteorsResults[j + 1] = m;
                }
            }
        }
    }
    meteorsCount--;
    removedCount++;


    uniqueLock.unlock();

    if (meteorsCount == 0) {
        setRemoveDone(true);
        setFillDone(false);
        fillMonitorCV.notify_one();
    }
}

Monitor::Monitor() {

}

/*
void Monitor::putResult(Meteor meteor) {

    std::unique_lock<std::mutex> uniqueLock(mutex);

    if (meteorsCount >= meteorsMaxCount) {
        fillMonitorCV.wait(uniqueLock, [&] {
            return meteorsCount >= meteorsMaxCount;
        });
    }

    if (meteor.GetHazardLevelLow())
        return;

    if (meteorsCount == 0) {
        meteors[meteorsCount++] = meteor;
    } else {
        for (int i = 0; i < meteorsCount + 1; i++) {
            if (meteors[i].GetHazardLevelLow() > meteor.GetHazardLevelLow()) {
                Meteor temp;
                for (int j = i; j < meteorsCount; j++) {
                    temp = meteor;
                    meteor = meteors[j];
                    meteors[j] = temp;
                }
            }
        }
    }

    uniqueLock.unlock();

    emptyMonitorCV.notify_one();
}
*/

bool Monitor::getFillDone() {
    return fillDone;
}

void Monitor::setFillDone(bool fill) {
    fillDone = fill;
}

void Monitor::setRemoveDone(bool remove) {
    removeDone = remove;
}

bool Monitor::getRemoveDone() {
    return removeDone;
}

bool Monitor::getAllInputsDone() {
    return putCount == ARRAY_SIZE;
}

bool Monitor::getAllRemovesDone() {
    return removedCount == ARRAY_SIZE;
}
