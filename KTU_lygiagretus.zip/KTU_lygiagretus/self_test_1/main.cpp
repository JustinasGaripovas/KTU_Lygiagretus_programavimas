#include <iostream>
#include <fstream>
#include "Meteor.h"
#include "json.hpp"
#include "Monitor.h"
#include <string>
#include <thread>
#include <iomanip>

using json = nlohmann::json;
using namespace std;

const int CURRENT_MODE = 0;

const std::basic_string<char> INPUT_FILE_PATHS[3] = {
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/IFF7-9_GaripovasJ_L1a_dat_1.json",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/IFF7-9_GaripovasJ_L1a_dat_2.json",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/IFF7-9_GaripovasJ_L1a_dat_3.json"
};

const std::basic_string<char> OUTPUT_FILE_PATHS[3] = {
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/result1.txt",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/result2.txt",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_1/result3.txt"
};

Meteor meteors[ARRAY_SIZE];

int insertCounter = 0;

Monitor initialMonitor;
Monitor resultMonitor;

void InputFromFile(std::basic_string<char> filename);

void OutputFileToConsole(std::basic_string<char> filename);

void OutputMonitorToFile(std::basic_string<char> filename);

vector<thread> ThreadCalculations();

void MonitorInsert();

void Calculate();

int main() {
    InputFromFile(INPUT_FILE_PATHS[CURRENT_MODE]);

    vector<thread> threads = ThreadCalculations();

    for (std::thread & th : threads)
    {
        th.join();
    }

    for (int i = 0; i < initialMonitor.meteorResultCount; ++i) {
        cout << initialMonitor.meteorsResults[i].ToString() << endl;
    }

    OutputMonitorToFile(OUTPUT_FILE_PATHS[CURRENT_MODE]);
}

void OutputMonitorToFile(string filename)
{
    ofstream fw(filename, ofstream::out);
    fw << left << setw(9) << "Meteoras" << setw(65) << "|Pavadinimas" << setw(20) << "|Pavojaus lygis" << setw(15) << "|Greitis" << setw(12) << "|Diametras " << endl;
    fw << "------------------------------------------------------------------------------------------------------------------------\n";
    for (int i = 0; i < initialMonitor.meteorResultCount; i++)
    {
        Meteor m = initialMonitor.meteorsResults[i];

        fw << left << setw(9) << i+1 << setw(65) << m.GetName() << setw(20) << m.GetHazardLevel() << setw(15) << m.GetVelocity() << setw(12) << m.GetDiameter() << endl;
    }
    fw.close();
    cout << endl;
}

void MonitorInsert() {
    while (insertCounter < ARRAY_SIZE)
            initialMonitor.put(meteors[insertCounter++]);
}

void Calculate() {
    initialMonitor.remove();
    initialMonitor.remove();
    initialMonitor.remove();
    initialMonitor.remove();
}

vector<thread> ThreadCalculations() {

    int threadCount = ARRAY_SIZE-1;

    vector<thread> threads;
    threads.reserve(threadCount+1);

    thread t(MonitorInsert);
    threads.push_back(move(t));

    for (int x = 0; x <= 7; x++) {
        thread thread(Calculate);
        threads.push_back(move(thread));
    }

    return threads;
}

void OutputFileToConsole(string filename) {
    std::ifstream file(filename);

    string line;
    if (file.is_open()) {
        while (getline(file, line)) {
            cout << line << '\n';
        }
        file.close();
    }
}


void InputFromFile(string filename) {

    std::ifstream file(filename);

    json data;
    file >> data;

    int index = 0;
    for (json::iterator it = data.begin(); it != data.end(); it++) {
        std::string name = it.value().value("name", "");
        int hazard_level = it.value().value("hazard_level", 0);
        double relative_velocity = it.value().value("relative_velocity", 0.0);
        double diameter = it.value().value("diameter", 0.0);

        meteors[index].SetMeteorValues(name, diameter, relative_velocity, hazard_level);

        index++;
    }
}