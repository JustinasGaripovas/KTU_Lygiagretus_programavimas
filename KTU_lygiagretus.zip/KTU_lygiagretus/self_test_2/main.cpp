#pragma clang diagnostic push
#pragma ide diagnostic ignored "openmp-use-default-none"
#include <iostream>
#include <fstream>
#include "Meteor.h"
#include "json.hpp"
#include "Monitor.h"
#include <string>
#include <iomanip>
#include <omp.h>

using json = nlohmann::json;
using namespace std;

const int CURRENT_MODE = 0;

const std::basic_string<char> INPUT_FILE_PATHS[3] = {
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_2/IFF7-9_GaripovasJ_L1a_dat_1.json",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_2/IFF7-9_GaripovasJ_L1a_dat_2.json",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_2/IFF7-9_GaripovasJ_L1a_dat_3.json"
};

const std::basic_string<char> OUTPUT_FILE_PATHS[3] = {
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_2/result1.txt",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_2/result2.txt",
        "/home/justin/CLionProjects/KTU_lygiagretus/self_test_2/result3.txt"
};

Meteor meteors[ARRAY_SIZE];

int insertCounter = 0;

Monitor initialMonitor;

void InputFromFile(std::basic_string<char> filename);

void OutputFileToConsole(std::basic_string<char> filename);

void OutputMonitorToFile(std::basic_string<char> filename);

void ThreadCalculations();

void MonitorInsert();

void Calculate();

int main() {

    InputFromFile((string) INPUT_FILE_PATHS[CURRENT_MODE]);

    ThreadCalculations();

    #pragma omp barrier
        OutputMonitorToFile(OUTPUT_FILE_PATHS[CURRENT_MODE]);

}

void OutputMonitorToFile(string filename)
{
    ofstream fw(filename, ofstream::out);
    fw << left << setw(9) << "Meteoras" << setw(65) << "|Pavadinimas" << setw(20) << "|Pavojaus lygis" << setw(15) << "|Greitis" << setw(12) << "|Diametras " << endl;
    fw << "------------------------------------------------------------------------------------------------------------------------\n";
    for (int i = 0; i < initialMonitor.meteorResultCount; i++)
    {
        Meteor m = initialMonitor.meteorsResults[i];

        fw << left << setw(9) << i+1 << setw(65) << m.GetName() << setw(20) << m.GetHazardLevel() << setw(15) << m.GetVelocity() << setw(12) << m.GetDiameter() << endl;
    }
    fw.close();
    cout << endl;
}

void MonitorInsert() {
    while (insertCounter < ARRAY_SIZE)
            initialMonitor.put(meteors[insertCounter++]);
}

void Calculate() {
    initialMonitor.remove();
    initialMonitor.remove();
    initialMonitor.remove();
    initialMonitor.remove();
}

void ThreadCalculations() {
    int tid = 0; // thread id
    int i=0;
#pragma omp parallel firstprivate(i) num_threads(8)
    {
        int tid = omp_get_thread_num();

        if (tid == 0)
        {
            MonitorInsert();
        }
        else
        {
            Calculate();
        }
    }
}

void OutputFileToConsole(string filename) {
    std::ifstream file(filename);

    string line;
    if (file.is_open()) {
        while (getline(file, line)) {
            cout << line << '\n';
        }
        file.close();
    }
}


void InputFromFile(string filename) {

    std::ifstream file(filename);

    json data;
    file >> data;

    int index = 0;
    for (json::iterator it = data.begin(); it != data.end(); it++) {
        std::string name = it.value().value("name", "");
        int hazard_level = it.value().value("hazard_level", 0);
        double relative_velocity = it.value().value("relative_velocity", 0.0);
        double diameter = it.value().value("diameter", 0.0);

        meteors[index].SetMeteorValues(name, diameter, relative_velocity, hazard_level);

        index++;
    }
}

#pragma clang diagnostic pop